//============================================================================
// Name        : DSAL_21129_Assignment_6.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#define N 13

class Node{
private:
	int data=-1;
	Node* nbrs[N];
public:
	Node(){
		for(int i=0;i<N;i++){
			nbrs[i]=NULL;
		}
	}
	Node(int d){
		data=d;
		for(int i=0;i<N;i++){
			nbrs[i]=NULL;
		}
	}
	int get_data(){return data;}
	void set_data(int d){data=d;}
	Node* get_nbr(int i){return nbrs[i];}
	void set_nbr(int i,Node* node){nbrs[i]=node;}
};

class Queue{
private:
	int q[N*N];
	int f=0,b=0;
public:
	Queue(){
		for(int i=0;i<N*N;i++){
			q[i]=-1;
		}
	}
	void enqueue(int p){q[b++]=p;}
	int dequeue(){return q[f++];}
	bool isempty(){
		return f==b;
	}
};

class AL{
private:
	Node* arr[N];
	int ptrs[N];
	bool visited[N];
public:
	AL(){
		for(int i=0;i<N;i++){
			arr[i]=new Node(i);
			ptrs[i]=0;
			visited[i]=false;
		}
	}
	void reset_visited(){
		for(int i=0;i<N;i++){
			visited[i]=false;
		}
	}
	void set_vis(int i){visited[i]=true;}
	void insert(){
		int u,v;
		cin>>u;cin>>v;
		arr[u]->set_nbr(ptrs[u]++, arr[v]);
		arr[v]->set_nbr(ptrs[v]++, arr[u]);
	}
	void dfs(int p){
		cout<<p<<" ";
		for(int i=0;i<ptrs[p];i++){
			if(!visited[(arr[p]->get_nbr(i))->get_data()]){
				visited[(arr[p]->get_nbr(i))->get_data()]=true;
				dfs((arr[p]->get_nbr(i))->get_data());
			}
		}
	}
	void bfs(int p){
		Queue queue=Queue();
		queue.enqueue(p);
		visited[p]=true;
		int i;
		while(!queue.isempty()){
			i=queue.dequeue();
			cout<<i<<" ";
			for(int j=0;j<ptrs[i];j++){
				if(!visited[arr[i]->get_nbr(j)->get_data()]){
					visited[arr[i]->get_nbr(j)->get_data()]=true;
					queue.enqueue(arr[i]->get_nbr(j)->get_data());
				}
			}
		}
	}
	void showlist(){
		for(int i=0;i<N;i++){
			cout<<"node: "<<i<<"=> ";
			for(int j=0;j<ptrs[i];j++){
				cout<<(arr[i]->get_nbr(j))->get_data()<<" ";
			}
			cout<<endl;
		}
	}
};

int main() {
	int c;
	AL adj=AL();
	while(true){
		cout<<"What to do?"<<endl;
		cout<<"1. Insert a new edge"<<endl;
		cout<<"2. Perform dfs and bfs"<<endl;
		cout<<"3. Show adjacency list"<<endl;
		cout<<"4. Exit"<<endl;
		cin>>c;
		switch(c){
		case 1:adj.insert();break;
		case 2:
			cout<<"From node: ";cin>>c;
			adj.set_vis(c);
			cout<<"dfs: ";adj.dfs(c);cout<<endl;adj.reset_visited();
			cout<<"bfs: ";adj.bfs(c);cout<<endl;adj.reset_visited();
			break;
		case 3:adj.showlist();break;
		case 4:return 0;
		default:;
		}
	}
	return 0;
}

/*
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
1 2
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
1 7
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
1 8
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
2 3
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
2 4
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
2 6
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
3 4
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
3 5
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
3 7
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
5 10
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
8 9
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
8 12
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
9 10
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
9 11
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
1
10 12
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
3
node: 0=>
node: 1=> 2 7 8
node: 2=> 1 3 4 6
node: 3=> 2 4 5 7
node: 4=> 2 3
node: 5=> 3 10
node: 6=> 2
node: 7=> 1 3
node: 8=> 1 9 12
node: 9=> 8 10 11
node: 10=> 5 9 12
node: 11=> 9
node: 12=> 8 10
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
2
From node: 1
dfs: 1 2 3 4 5 10 9 8 12 11 7 6
bfs: 1 2 7 8 3 4 6 9 12 5 10 11
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
2
From node: 9
dfs: 9 8 1 2 3 4 5 10 12 7 6 11
bfs: 9 8 10 11 1 12 5 2 7 3 4 6
What to do?
1. Insert a new edge
2. Perform dfs and bfs
3. Show adjacency list
4. Exit
4
 */
