class TeleNo:
    def __init__(self):
        self.name=input("Enter Name: ")
        self.phone=int(input("Enter Phone: "))
    def __str__(self):
        return f"{self.name} : {self.phone}"
class HashTable:
    def __init__(self,n):
        self.htable=[]
        for i in range(n):
            self.htable.append(None)
    def insertWOR(self,data):
        n=len(self.htable)
        count=1
        i=(data.phone)%n
        while(self.htable[i]!=None) and count<n:
            count+=1
            i=(i+1)%n
        if count==n:
            return "Table full! Cannot insert"
        self.htable[i] = data
        return "Inserted!"
    def insertWR(self,data):
        n = len(self.htable)
        count = 1
        i = (data.phone) % n
        if self.htable[i] == None:
            self.htable[i] = data
            return "Inserted!"
        elif (self.htable[i].phone)%n==i:
            while (self.htable[i] != None) and count < n:
                count += 1
                i = (i + 1) % n
            if count == n:
                return "Table full! Cannot insert"
            self.htable[i] = data
            return "Inserted!"
        else:
            data,self.htable[i]=self.htable[i],data
            while (self.htable[i] != None) and count < n:
                count += 1
                i = (i + 1) % n
            if count == n:
                i = (i + 1) % n
                self.htable[i] = data
                return "Table full! Cannot insert"
            self.htable[i] = data
            return "Inserted!"

    def searchWOR(self,phone):
        n = len(self.htable)
        count = 1
        i = (phone) % n
        while (self.htable[i] != None) and count<n:
            if self.htable[i].phone==phone:
                return i,count
            count += 1
            i = (i + 1) % n
        else:
            if count==n and self.htable[i] != None:
                if self.htable[i].phone==phone:
                    return i, count
        return None,count
    def updateWOR(self,phone):
        i,count=self.searchWOR(phone)
        if i==None:
            return "Not Found to update"
        self.htable[i].name=input("Enter New name: ")
        return "Updated!"
    def deleteWOR(self,phone):
        i,count = self.searchWOR(phone)
        if i == None:
            return "Not Found to delete"
        x=self.htable[i]
        self.htable[i] = None
        del x
        return "Deleted!"
    def displayAll(self):
        print("name : phone")
        for i in self.htable:
            print(i)

ght=HashTable(int(input("Size of table: ")))
menu=["What to perform?","1. Insert a Contact","2. Search a Contact","3. Update a Contact","4. Delete a Contact","5. Display All","6. Insert with Replacement","7. Exit"]
while True:
    for i in menu:
        print(i)
    t=int(input())
    if t==7:
        print("Thank you")
        break
    if t==1:
        temp=TeleNo()
        print(ght.insertWOR(temp))
    elif t==2:
        temp,count=ght.searchWOR(int(input("Enter Phone to search: ")))
        if temp==None:
            print("Not Found")
        else:
            print(f"Comparisons made: {count}")
            print(ght.htable[temp])
    elif t==3:
        temp=ght.updateWOR(int(input("Enter Phone to search: ")))
        print(temp)
    elif t==4:
        temp = ght.deleteWOR(int(input("Enter Phone to search: ")))
        print(temp)
    elif t==5:
        ght.displayAll()
    elif t==6:
        temp = TeleNo()
        print(ght.insertWR(temp))


"""
Size of table: 10
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: a
Enter Phone: 79
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: b
Enter Phone: 85
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: c
Enter Phone: 29
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: d
Enter Phone: 40
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: e
Enter Phone: 77
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: f
Enter Phone: 67
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: g
Enter Phone: 88
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: h
Enter Phone: 75
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: i
Enter Phone: 66
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: j
Enter Phone: 33
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
1
Enter Name: 2
Enter Phone: 2
Table full! Cannot insert
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
5
name : phone
c : 29
d : 40
g : 88
i : 66
j : 33
b : 85
h : 75
e : 77
f : 67
a : 79
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
2
Enter Phone to search: 29
Comparisons made: 2
c : 29
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
2
Enter Phone to search: 66
Comparisons made: 8
i : 66
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
3
Enter Phone to search: 88
Enter New name: k
Updated!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
5
name : phone
c : 29
d : 40
k : 88
i : 66
j : 33
b : 85
h : 75
e : 77
f : 67
a : 79
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
4
Enter Phone to search: 67
Deleted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
5
name : phone
c : 29
d : 40
k : 88
i : 66
j : 33
b : 85
h : 75
e : 77
None
a : 79
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
7 
Thank you

Process finished with exit code 0

Size of table: 10
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
6
Enter Name: a
Enter Phone: 79
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
6
Enter Name: b
Enter Phone: 85
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
6
Enter Name: c
Enter Phone: 29
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
6
Enter Name: d
Enter Phone: 40
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
6
Enter Name: e
Enter Phone: 77
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
6
Enter Name: f
Enter Phone: 67
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
6
Enter Name: g
Enter Phone: 88
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
6
Enter Name: h
Enter Phone: 75
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
6
Enter Name: i
Enter Phone: 66
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
6
Enter Name: j
Enter Phone: 33
Inserted!
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
5
name : phone
d : 40
c : 29
f : 67
j : 33
h : 75
b : 85
i : 66
e : 77
g : 88
a : 79
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
2
Enter Phone to search: 29
Comparisons made: 3
c : 29
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
2
Enter Phone to search: 66
Comparisons made: 1
i : 66
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
2
Enter Phone to search: 75
Comparisons made: 10
h : 75
What to perform?
1. Insert a Contact
2. Search a Contact
3. Update a Contact
4. Delete a Contact
5. Display All
6. Insert with Replacement
7. Exit
7
Thank you

Process finished with exit code 0

"""




