//============================================================================
// Name        : DSAL_21129_Assignment_7.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#define N 9

class Edge{
private:
	int u=-1,v=-1,w=-1;
public:
	Edge(){}
	Edge(int x,int y,int z){
		u=x;v=y;w=z;
	}
	bool isbiggerthan(Edge e){
		return w>e.w;
	}
	int getU(){return u;}
	int getV(){return v;}
	int getW(){return w;}
	void displayEdge(){
		cout<<u<<" "<<v<<" "<<w<<endl;
	}
};

class AM{
private:
	int matrix[N][N];
	Edge edges[N*N];
	Edge* T[N];int t=0;
	int djs[N][N];int dptrs[N];
public:
	AM(){
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++){
				matrix[i][j]=0;
				djs[i][j]=-1;
				edges[N*i+j]=Edge();
			}
			dptrs[i]=0;
			T[i]=NULL;
		}
	}
	void insert(){
		int c,x,y,z;
		cout<<"Total edges: ";cin>>c;
		for(int i=0;i<c;i++){
			cin>>x;cin>>y;cin>>z;
			edges[i]=Edge(x,y,z);
			matrix[x][y]=z;
			matrix[y][x]=z;
		}
		sort(c);
	}
	void sort(int c){
		Edge curr;int pos;// insertion sort
		for(int i=1;i<c;i++){
			curr=edges[i];
			pos=i;
			while(pos>0 && edges[pos-1].isbiggerthan(curr)){
				edges[pos]=edges[pos-1];
				pos--;
			}
			edges[pos]=curr;
		}
	}
	bool checkCycle(int u,int v){
		int j=-1,k=-1;
		bool x,y;
		for(int i=0;i<N;i++){
			x=false;y=false;
			for(int h=0;h<dptrs[i];h++){
				x=(x||(djs[i][h]==u));
				y=(y||(djs[i][h]==v));
			}
			if(x && y) return false;
			if(x) j=i;
			else if(y) k=i;
		}
		if(j==-1 && k==-1){
			for(int i=0;i<N;i++){
				if(dptrs[i]==0){
					djs[i][0]=u;
					djs[i][1]=v;
					dptrs[i]=2;
					return true;
				}
			}
		}
		if(j==-1){djs[k][dptrs[k]++]=u;return true;}
		if(k==-1){djs[j][dptrs[j]++]=v;return true;}
		for(int i=0;i<dptrs[k];i++){
			djs[j][dptrs[j]++]=djs[k][i];
		}
		dptrs[k]=0;
		return true;
	}
	void showRoute(){
		for(int i=0;i<t;i++){
			T[i]->displayEdge();
		}
	}
	void showDisjointSets(){
		for(int i=0;i<N;i++){
			for(int j=0;j<dptrs[i];j++){
				cout<<djs[i][j]<<" ";
			}
			if(dptrs[i]!=0)cout<<",";
		}
		cout<<endl;
	}
	void kruskal(){
		int i=0,u,v,w,W=0;
		while(edges[i].getU()+1!=0){
			u=edges[i].getU();
			v=edges[i].getV();
			w=edges[i].getW();
			if(checkCycle(u,v)){
				T[t++]=&edges[i];
				W+=w;
			}
			cout<<"djs=>";showDisjointSets();
			if(t==N-1){
				cout<<"Total Weight: "<<W<<endl;
				showRoute();
				return;
			}
			i++;
		}
		cout<<"Total Weight: "<<W<<endl;
		showRoute();
		return;
	}
	void displayMatrix(){
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++){
				cout<<matrix[i][j]<<" ";
			}
			cout<<endl;
		}
	}
};

int main() {
	int c;
	AM adj=AM();
	while(true){
		cout<<"What to do?"<<endl;
		cout<<"1. Insert new Graph"<<endl;
		cout<<"2. Display adjacency matrix"<<endl;
		cout<<"3. Apply Kruskal algo"<<endl;
		cout<<"4. Exit"<<endl;
		cin>>c;
		switch(c){
		case 1:adj.insert();break;
		case 2:adj.displayMatrix();break;
		case 3:adj.kruskal();break;
		case 4:return 0;
		default:;
		}
	}
	return 0;
}

/*

What to do?
1. Insert new Graph
2. Display adjacency matrix
3. Apply Kruskal algo
4. Exit
1
Total edges: 14
0 1 4
0 7 8
1 7 11
7 8 7
7 6 1
1 2 8
2 8 2
8 6 6
6 5 2
2 5 4
2 3 7
3 4 9
3 5 14
5 4 10
What to do?
1. Insert new Graph
2. Display adjacency matrix
3. Apply Kruskal algo
4. Exit
2
0 4 0 0 0 0 0 8 0
4 0 8 0 0 0 0 11 0
0 8 0 7 0 4 0 0 2
0 0 7 0 9 14 0 0 0
0 0 0 9 0 10 0 0 0
0 0 4 14 10 0 2 0 0
0 0 0 0 0 2 0 1 6
8 11 0 0 0 0 1 0 7
0 0 2 0 0 0 6 7 0
What to do?
1. Insert new Graph
2. Display adjacency matrix
3. Apply Kruskal algo
4. Exit
3
djs=>7 6 ,
djs=>7 6 ,2 8 ,
djs=>7 6 5 ,2 8 ,
djs=>7 6 5 ,2 8 ,0 1 ,
djs=>2 8 7 6 5 ,0 1 ,
djs=>2 8 7 6 5 ,0 1 ,
djs=>2 8 7 6 5 ,0 1 ,
djs=>2 8 7 6 5 3 ,0 1 ,
djs=>0 1 2 8 7 6 5 3 ,
djs=>0 1 2 8 7 6 5 3 ,
djs=>0 1 2 8 7 6 5 3 4 ,
Total Weight: 37
7 6 1
2 8 2
6 5 2
0 1 4
2 5 4
2 3 7
0 7 8
3 4 9
What to do?
1. Insert new Graph
2. Display adjacency matrix
3. Apply Kruskal algo
4. Exit
4

 */
