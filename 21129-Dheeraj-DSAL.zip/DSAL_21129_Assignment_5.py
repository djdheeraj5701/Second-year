class HashTable:
    def __init__(self):
        self.key=[]
        self.value=[]
        self.chain=[]
        for i in range(10):
            self.key.append(None)
            self.value.append(None)
            self.chain.append(-1)

    def isChained(self,s):
        return self.chain[s]!=-1

    def changeChain(self,s,t):
        self.chain[s]=t

    def linearProbe(self,k):
        i=(k+1)%10
        while i!=(k%10):
            if not self.key[i]:
                return i
            i=(i+1)%10
        return -1

    def insertWOR(self,k,v):
        i=k%10
        if (not self.key[i]):
            self.key[i]=k
            self.value[i]=v
            return "Inserted!"
        while self.chain[i]!=-1:
            i=self.chain[i]
        j = self.linearProbe(i)
        if j == -1:
            return "It's full! Can't insert vro"
        self.key[j] = k
        self.value[j] = v
        self.changeChain(i, j)
        return "Inserted!"

    def insertWR(self,k,v):
        i = k % 10
        if (not self.key[i]):
            self.key[i] = k
            self.value[i] = v
            return "Inserted!"
        elif self.key[i]%10==i:
            while self.chain[i] != -1:
                i = self.chain[i]
            j = self.linearProbe(i)
            if j == -1:
                return "It's full! Can't insert vro"
            self.key[j] = k
            self.value[j] = v
            self.changeChain(i,j)
            return "Inserted!"
        else:
            if self.linearProbe(0)==-1:
                return "It's full! Can't insert vro"
            ck,cv,cc=self.key[i],self.value[i],self.chain[i]
            self.key[i], self.value[i], self.chain[i]=k,v,-1
            x=-1
            for cx in range(10):
                if self.chain[cx]==i:
                    x=cx
                    break
            j=self.linearProbe(i)
            self.key[j], self.value[j], self.chain[j]=ck,cv,cc
            self.chain[x]=j
            return "Inserted!"

    def search(self,k):
        i=k%10
        count=1
        if self.key[i]==k:
            return i,count
        while self.isChained(i):
            i=self.chain[i]
            count+=1
            if self.key[i] == k:
                return i, count
            if self.chain[i]==k%10:
                break
        return -1,count

    def remove(self,i):
        self.key[i], self.value[i] = None, None
        for j in range(10):
            if self.chain[j]==i:
                self.chain[j]=self.chain[i]


    def display(self):
        print("Key Value Chain")
        for i in range(10):
            print(self.key[i],self.value[i],self.chain[i])

class Dictionary:
    def __init__(self):
        self.bucket=HashTable()

    def addKeyVal(self,i):
        key=int(input("Enter key: "))
        val=input("Enter val: ")
        if i:
            return self.bucket.insertWR(key,val)
        return self.bucket.insertWOR(key,val)

    def findKey(self):
        key = int(input("Enter key: "))
        i,count=self.bucket.search(key)
        if i==-1:
            return f"Not found. count={count}"
        return f"Found at i={i}, count={count}"

    def updateVal(self):
        key = int(input("Enter key: "))
        i, count = self.bucket.search(key)
        if i == -1:
            return "Not found. Can't update"
        val = input("Enter newVal: ")
        self.bucket.value[i]=val
        return "Updated!"

    def deleteKey(self):
        key = int(input("Enter key: "))
        i, count = self.bucket.search(key)
        if i == -1:
            return "Not found. LOL"
        self.bucket.remove(i)
        return "Deleted!"

    def display(self):
        self.bucket.display()

menu=[
    "What to perform?",
    "1. Insert without Replacement",
    "2. Search",
    "3. Update",
    "4. Delete",
    "5. Display All",
    "6. Insert with Replacement",
    "7. Exit"]
d=Dictionary()
while True:
    for i in menu:
        print(i)
    t=int(input("Enter choice: "))
    if t==7:
        print("Thank you")
        break
    if t==1:
        print(d.addKeyVal(0))
    if t==2:
        print(d.findKey())
    if t==3:
        print(d.updateVal())
    if t==4:
        print(d.deleteKey())
    if t==5:
        d.display()
    if t==6:
        print(d.addKeyVal(1))

'''
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 1
Enter key: 79
Enter val: a
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 1
Enter key: 85
Enter val: b
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 1
Enter key: 29
Enter val: c
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 1
Enter key: 40
Enter val: d
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 1
Enter key: 77
Enter val: e
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 1
Enter key: 67
Enter val: f
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 1
Enter key: 88
Enter val: g
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 1
Enter key: 75
Enter val: h
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 1
Enter key: 66
Enter val: i
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 1
Enter key: 33
Enter val: j
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 5
Key Value Chain
29 c 1
40 d -1
88 g -1
66 i 4
33 j -1
85 b 6
75 h 3
77 e 8
67 f 2
79 a 0
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 2
Enter key: 75
Found at i=6, count=2
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 4
Enter key: 85
Deleted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 5
Key Value Chain
29 c 1
40 d -1
88 g -1
66 i 4
33 j -1
None None 6
75 h 3
77 e 8
67 f 2
79 a 0
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 7
Thank you

Process finished with exit code 0


What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 6
Enter key: 79
Enter val: a
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 6
Enter key: 85
Enter val: b
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 6
Enter key: 29
Enter val: c
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 6
Enter key: 40
Enter val: d
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 6
Enter key: 77
Enter val: e
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 6
Enter key: 67
Enter val: f
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 6
Enter key: 88
Enter val: g
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 6
Enter key: 75
Enter val: h
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 6
Enter key: 66
Enter val: i
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 6
Enter key: 33
Enter val: j
Inserted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 5
Key Value Chain
40 d -1
29 c -1
67 f -1
33 j -1
75 h -1
85 b 4
66 i -1
77 e 2
88 g -1
79 a 1
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 2
Enter key: 75
Found at i=4, count=2
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 4
Enter key: 85
Deleted!
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 5
Key Value Chain
40 d -1
29 c -1
67 f -1
33 j -1
75 h -1
None None 4
66 i -1
77 e 2
88 g -1
79 a 1
What to perform?
1. Insert without Replacement
2. Search
3. Update
4. Delete
5. Display All
6. Insert with Replacement
7. Exit
Enter choice: 7
Thank you

Process finished with exit code 0

'''

