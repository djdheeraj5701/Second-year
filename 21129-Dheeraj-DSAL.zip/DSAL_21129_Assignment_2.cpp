//============================================================================
// Name        : DSAL_21129_Assignment_2.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Node{
private:
	string keyword,meaning;
	Node *child[2];
public:
	Node(string keyword,string meaning){
		this->keyword=keyword;
		this->meaning=meaning;
		child[0]=NULL;child[1]=NULL;
	}
	void change_meaning(string m){
		meaning=m;
	}
	string get_meaning(){
		return meaning;
	}
	static int cmp(Node*p,Node*q){
		int len=min(p->keyword.length(),q->keyword.length());
		for(int i=0;i<len;i++){
			if(p->keyword[i]<q->keyword[i]){
				return 0;
			}else if(p->keyword[i]>q->keyword[i]){
				return 1;
			}
		}
		if(p->keyword.length()==len){
			if(q->keyword.length()==len){
				return -1;
			}
			return 0;
		}
		return 1;
	}
	static int cmpk(string k,Node*q){
		int len=min(k.length(),q->keyword.length());
		for(int i=0;i<len;i++){
			if(k[i]<q->keyword[i]){
				return 0;
			}else if(k[i]>q->keyword[i]){
				return 1;
			}
		}
		if(k.length()==len){
			if(q->keyword.length()==len){
				return -1;
			}
			return 0;
		}
		return 1;
	}
	string display(){
		return keyword+" : "+meaning;
	}
	bool hasChild(int t){
		return child[t]!=NULL;
	}
	Node* getChild(int t){
		return child[t];
	}
	void setChild(int t,Node* c){
		child[t]=c;
	}
	bool hasKeyword(string k){
		return keyword==k;
	}
	void setKeyword(string k){
		keyword=k;
	}
	string getKeyword(){
		return keyword;
	}

};

class Dictionary{
public:
	Node* root;
	Dictionary(){
		root=NULL;
	}
	void add_word(){
		string t1,t2;
		cout<<"Enter keyword: ";cin>>t1;
		cout<<"Enter meaning: ";cin>>t2;
		Node *curr=new Node(t1,t2);
		if(root==NULL){
			root=curr;
			cout<<"{ "<<t1<<" : "<<t2<<" } set as root"<<endl;
			return;
		}else{
			Node *p=root;int temp;
			while(true){
				cout<<"Current word=> "<<p->display()<<endl;
				temp=Node::cmp(curr,p);
				if(temp==-1){
					cout<<"Keyword exists.Replacing the meaning...."<<endl;
					p->change_meaning(t2);return;
				}
				if(p->hasChild(temp)){
					p=p->getChild(temp);
				}else{
					p->setChild(temp,curr);
					cout<<"{ "<<t1<<" : "<<t2<<" } set as child"<<endl;
					return;
				}
			}
		}
	}
	void perform_order(int order,Node *q){
		switch(order){
		case 1:
			if(q){
				perform_order(order,q->getChild(0));
				cout<<q->display()<<endl;
				perform_order(order,q->getChild(1));
				return;
			}else{
				return;
			}
			break;
		case 2:
			if(q){
				perform_order(order,q->getChild(1));
				cout<<q->display()<<endl;
				perform_order(order,q->getChild(0));
				return;
			}else{
				return;
			}
			break;
		}
	}
	void eraseK(string k){
		if(root==NULL){
			cout<<"Root is null.Can't erase"<<endl;
			return;
		}else{
			Node *p=root,*q=root;int c=2;
			while(p!=NULL){
				cout<<"Current word: "<<p->display()<<endl;
				if(p->hasKeyword(k)){
					//case 1: leaf
					if(!(p->hasChild(0)) && !(p->hasChild(1))){
						if(c==2){
							delete p;
							root=NULL;return;
						}
						q->setChild(c,NULL);
						delete p;
						return;
					}
					// case 2: not leaf
					if(!(p->hasChild(1))){// case 2.1: no right
						if(c==2){
							root=p->getChild(0);
							delete p;
							return;
						}
						q->setChild(0,p->getChild(0));// direct attach
						p->setChild(0,NULL);
						delete p;
						return;
					}
					Node *r=p;// case 2.2: right
					q=p;
					p=p->getChild(1);
					while(p->hasChild(0)){
						q=p;
						p=p->getChild(0);
					}// leftmost of rightchild achieved
					r->setKeyword(p->getKeyword());
					r->change_meaning(p->get_meaning());
					if(q!=r){
						q->setChild(0,NULL);
					}else{
						q->setChild(1,p->getChild(1));
					}
					if(p->hasChild(1)){// cant erase child so direct
						q->setChild(0,p->getChild(1));
						p->setChild(1,NULL);
					}
					delete p;
					return;
				}else{
					q=p;
					c=Node::cmpk(k,q);
					p=p->getChild(c);
				}
			}
			cout<<k<<" not present to delete"<<endl;
			return;
		}
	}
	void find_Kword(){
		string t1;int count=0;
		cout<<"Enter keyword: ";cin>>t1;
		if(root==NULL){
			cout<<"Root is null."<<endl;
			cout<<"Comparison: "<<0<<endl;
			return;
		}else{
			Node *p=root;int temp;
			while(true){
				cout<<"Current word: "<<p->getKeyword()<<endl;
				temp=Node::cmpk(t1,p);count++;
				if(temp==-1){
					cout<<"Keyword found\nComparison: "<<count<<endl;
					cout<<"Max Comparisons: "<<tree_height(root,0)<<endl;
					return;
				}
				if(p->hasChild(temp)){
					p=p->getChild(temp);
				}else{
					cout<<"Keyword not found\nComparison: "<<count<<endl;
					cout<<"Max Comparisons: "<<tree_height(root,0)<<endl;
					return;
				}
			}
		}
	}
	void upd_word(){
			string t1;
			cout<<"Enter keyword: ";cin>>t1;
			if(root==NULL){
				cout<<"Root is null."<<endl;
				return;
			}else{
				Node *p=root;int temp;
				while(true){
					cout<<"Current word: "<<p->getKeyword()<<endl;
					temp=Node::cmpk(t1,p);
					if(temp==-1){
						cout<<"Keyword found\nEnter new meaning: ";cin>>t1;
						p->change_meaning(t1);
						cout<<"meaning changed"<<endl;
						return;
					}
					if(p->hasChild(temp)){
						p=p->getChild(temp);
					}else{
						cout<<"Keyword not found"<<endl;
						return;
					}
				}
			}
		}
	int tree_height(Node *q,int height){
		if(root==NULL){
			return 0;
		}
		if(q){
			return max(
				tree_height(q->getChild(0),height+1),
				tree_height(q->getChild(1),height+1));
		}else{
			return height;
		}
	}

};

int main() {
	Dictionary *btt=new Dictionary();string k;
	int c;
	while(true){
		cout<<"What to perform?"<<endl;
		cout<<"1. Insert a new word"<<endl;
		cout<<"2. Display all the words"<<endl;
		cout<<"3. Change the meaning"<<endl;
		cout<<"4. Find the word and max comparison"<<endl;
		cout<<"5. Erase a word"<<endl;
		cout<<"6. Exit"<<endl;
		cin>>c;
		if(c==6){
			cout<<"Thank you"<<endl;break;
		}
		switch(c){
		case 1:btt->add_word();break;
		case 2:
			cout<<"Choose from the following"<<endl;
			cout<<"1. Ascending\t2. Descending"<<endl;
			cin>>c;
			btt->perform_order(c, btt->root);
			cout<<endl;
			break;
		case 3:
			btt->add_word();
			break;
		case 4:
			btt->find_Kword();
			break;
		case 5:
			cout<<"Enter Keyword: ";
			cin>>k;
			btt->eraseK(k);break;
		}
	}
	return 0;
}

/*
 * What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
1
Enter keyword: s
Enter meaning: t
{ s : t } set as root
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
1
Enter keyword: e
Enter meaning: e
Current word=> s : t
{ e : e } set as child
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
1
Enter keyword: v
Enter meaning: v
Current word=> s : t
{ v : v } set as child
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
1
Enter keyword: c
Enter meaning: c
Current word=> s : t
Current word=> e : e
{ c : c } set as child
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
1
Enter keyword: f
Enter meaning: f
Current word=> s : t
Current word=> e : e
{ f : f } set as child
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
1
Enter keyword: a
Enter meaning: a
Current word=> s : t
Current word=> e : e
Current word=> c : c
{ a : a } set as child
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
1
Enter keyword: x
Enter meaning: x
Current word=> s : t
Current word=> v : v
{ x : x } set as child
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
1
Enter keyword: u
Enter meaning: u
Current word=> s : t
Current word=> v : v
{ u : u } set as child
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
1
Enter keyword: w
Enter meaning: w
Current word=> s : t
Current word=> v : v
Current word=> x : x
{ w : w } set as child
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
2
Choose from the following
1. Ascending	2. Descending
1
a : a
c : c
e : e
f : f
s : t
u : u
v : v
w : w
x : x

What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
2
Choose from the following
1. Ascending	2. Descending
2
x : x
w : w
v : v
u : u
s : t
f : f
e : e
c : c
a : a

What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
3
Enter keyword: f
Current word=> s : t
Current word=> e : e
Current word=> f : f
Keyword found
Enter new meaning: g
meaning changed
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
3
Enter keyword: m
Current word=> s : t
Current word=> e : e
Current word=> f : g
Keyword not found
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
1
Enter keyword: m
Enter meaning: m
Current word=> s : t
Current word=> e : e
Current word=> f : g
{ m : m } set as child
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
4
Enter keyword: u
Current word: s
Current word: v
Current word: u
Keyword found
Comparison: 3
Max Comparisons: 4
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
4
Enter keyword: n
Current word: s
Current word: e
Current word: f
Current word: m
Keyword not found
Comparison: 4
Max Comparisons: 4
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
5
Enter Keyword: f
Current word: s : t
Current word: e : e
Current word: f : g
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
2
Choose from the following
1. Ascending	2. Descending
1
a : a
c : c
e : e
m : m
s : t
u : u
v : v
w : w
x : x

What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
4
Enter keyword: m
Current word: s
Current word: e
Current word: m
Keyword found
Comparison: 3
Max Comparisons: 4
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
5
Enter Keyword: v
Current word: s : t
Current word: v : v
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
2
Choose from the following
1. Ascending	2. Descending
1
a : a
c : c
e : e
m : m
s : t
u : u
w : w
x : x

What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
4
Enter keyword: w
Current word: s
Current word: w
Keyword found
Comparison: 2
Max Comparisons: 4
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
5
Enter Keyword: s
Current word: s : t
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
2
Choose from the following
1. Ascending	2. Descending
1
a : a
c : c
e : e
m : m
u : u
w : w
x : x

What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
4
Enter keyword: d
Current word: u
Current word: e
Current word: c
Keyword not found
Comparison: 3
Max Comparisons: 4
What to perform?
1. Insert a new word
2. Display all the words
3. Change the meaning
4. Find the word and max comparison
5. Erase a word
6. Exit
6
Thank you
 */


