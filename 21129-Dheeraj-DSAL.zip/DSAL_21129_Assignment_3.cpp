//============================================================================
// Name        : DSAL_21129_Assignment_3.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>

using namespace std;

class Node{
private:
    int data;
    Node *left;
    Node *right;
    int lbit; // if 0 then thread else link
    int rbit;

public:
    Node(){ //default Constructor
        data = 0;
        left = NULL;
        right = NULL;
        lbit = 0;
        rbit = 0;
    }
    Node(int n){ //Parameterized Constructor
        data = n;
        left = NULL;
        right = NULL;
        lbit = 0;
        rbit = 0;
    }
    void Display(){
        cout << "Data: " << data << endl;
        cout << "Left: " << (left != NULL ? left->data : 0) << endl;
        cout << "Right: " << (right != NULL ? right->data : 0) << endl;
        cout << "Lbit: " << lbit << endl;
        cout << "Rbit: " << rbit << endl;
        cout << endl;
    }
    int getData(){
        return data;
    }

    friend class ThreadedBinaryTree;
};

class ThreadedBinaryTree{
private:
    Node *dummy;
    Node *root;
public:
    ThreadedBinaryTree(){
        dummy = new Node(99);
        dummy->right = dummy;
        dummy->left = root;
        dummy->lbit = 1;
        dummy->rbit = 1;
        root = NULL;
    }
    void Insert(int n);
    void CreateTree();
    void InOrder();
    void PreOrder();
    void Search(int k, Node *&node, Node *&par);
    void DeleteNode(int n);
};

void ThreadedBinaryTree::Insert(int n){
    if (root == NULL){
        root = new Node(n);
        root->left = dummy;
        root->right = dummy;
        root->lbit = 0;
        root->rbit = 0;
        return;
    }
    Node *par = root;
    Node *node = new Node(n);
    while (true){
        if (par->data > n){
            if (par->lbit == 1){
                par = par->left;
            }
            else{
                node->lbit = 0;
                node->rbit = 0;
                node->left = par->left;
                node->right = par;
                par->left = node;
                par->lbit = 1;
                return;
            }
        }
        else{
            if (par->rbit == 1){
                par = par->right;
            }
            else{
                node->lbit = 0;
                node->rbit = 0;
                node->left = par;
                node->right = par->right;
                par->right = node;
                par->rbit = 1;
                return;
            }
        }
    }
}
void ThreadedBinaryTree::CreateTree(){
    int n;
    while (true){
        cout << "Do you want to insert a Node(1/0): ";
        cin >> n;
        if (n == 1){
            cout << "Enter data of Node: ";
            cin >> n;
            Insert(n);
        }
        else{
            cout << "Threaded Binary Tree Successfully Created" << endl;
            break;
        }
    }
}
void ThreadedBinaryTree::InOrder(){
    Node *curNode = root;cout<<endl;
    while (curNode->lbit != 0){
        curNode = curNode->left;
    }
	while (curNode != dummy){
        curNode->Display();
        //cout << curNode->data << " ";
        if (curNode->rbit != 0){
            curNode = curNode->right;
            while (curNode->lbit != 0){
                curNode = curNode->left;
            }
        }
        else{
            curNode = curNode->right;
        }
    }
    cout << endl;
}
void ThreadedBinaryTree::Search(int k, Node *&node, Node *&par){
    node = NULL;
    par = NULL;
    if (root == NULL){
        cout << "Tree is Empty" << endl;
        return;
    }
    node = root;
    while (node != NULL and (node->rbit == 1 or node->lbit == 1)){
        if (node->data == k){
            return;
        }
        else if (node->data > k){
            par = node;
            node = node->left;
        }
        else{
            par = node;
            node = node->right;
        }
    }
}
void ThreadedBinaryTree::PreOrder(){
    Node *curNode = root;cout<<endl;
    while (curNode->data != 99){
    	curNode->Display();
        //cout << curNode->data << " ";
        if (curNode->lbit == 1){
            curNode = curNode->left;
        }
        else{
            if (curNode->rbit == 1){
                curNode = curNode->right;
            }
            else{
                while (curNode->rbit != 1){
                    curNode = curNode->right;
                }
                curNode = curNode->right;
            }
        }
    }
    cout << endl;
}
void ThreadedBinaryTree::DeleteNode(int n){
    Node *node = NULL;
    Node *par = NULL;
    Search(n, node, par);
    if (node->getData() != n){
    	cout << "Data Not Found to delete" << endl;
    	return;
    }
    if (node == NULL){
        cout << "Data Not Found to delete" << endl;
        return;
    }
    if (node->lbit == 1 && node->rbit == 1){
        par = node;
        Node *inSucc = node->right;
        while (inSucc->lbit != 0){
            par = inSucc;
            inSucc = inSucc->left;
        }
        node->data = inSucc->data;
        node = inSucc;
    }
    if (node->lbit == 0 and node->rbit == 0){
        if (par->left == node){
            par->left = node->left;
            par->lbit = 0;
        }
        else{
            par->right = node->right;
            par->rbit = 0;
        }
    }
    else if (node->lbit == 1 && node->rbit == 0){
        if (par->left == node){
            par->left = node->left;
        }
        else{
            par->right = node->left;
        }
        Node *temp = node->left;
        while (temp->rbit == 1){
            temp = temp->right;
        }
        temp->right = node->right;
    }
    else if (node->lbit == 0 && node->rbit == 1){
        if (par->left == node){
            par->left = node->right;
        }
        else{
            par->right = node->right;
        }
        Node *temp = node->right;
        while (temp->lbit == 1){
            temp = temp->left;
        }
        temp->left = node->left;
    }
    delete node;
    cout << "Deletion has been successfully completed." << endl;
}

int main(){
    ThreadedBinaryTree tbt;int n;int option;
    while (true){
        cout << "\nEnter the option:\n"<<
        		"1.Create Binary Search Tree \n"<<
        		"2.Insert Node \n"<<
        		"3.Delete Node \n"<<
        		"4.Inorder Traversal \n"<<
        		"5.Preorder Traversal \n"<<
        		"6.Search Key \n"<<
        		"7.Exit\n>>>";
        cin >> option;
        cout << endl;
        if (option == 7){
            cout << "Thank You!" << endl;
            break;
        }
        switch(option){
        case 1:
        	tbt.CreateTree();
        	break;
        case 2:
        	cout << "Enter Value: ";
        	cin >> n;
        	tbt.Insert(n);
        	cout << n << " has been inserted in Threaded binary Tree" << endl;
        	break;
        case 3:
        	cout << "Enter Value to be Deleted: ";
        	cin >> n;
        	tbt.DeleteNode(n);
        	break;
        case 4:
        	cout << "Threaded Binary Tree : ";
        	tbt.InOrder();
        	break;
        case 5:
        	cout << "Threaded Binary Tree : ";
        	tbt.PreOrder();
        	break;
        case 6:
        	cout << "Enter Value to be Searched: ";
			cin >> n;
			Node *node = NULL, *par = NULL;
			tbt.Search(n, node, par);
			if (node->getData() != n)
				cout << "Value not found!!!" << endl;
			else{
				cout << "Value found: " << endl;
				node->Display();
			}
        }
    }
    return 0;
}

/*
 *
Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>1

Do you want to insert a Node(1/0): 1
Enter data of Node: 10
Do you want to insert a Node(1/0): 1
Enter data of Node: 5
Do you want to insert a Node(1/0): 1
Enter data of Node: 3
Do you want to insert a Node(1/0): 1
Enter data of Node: 7
Do you want to insert a Node(1/0): 1
Enter data of Node: 6
Do you want to insert a Node(1/0): 1
Enter data of Node: 4
Do you want to insert a Node(1/0): 1
Enter data of Node: 11
Do you want to insert a Node(1/0): 0
Threaded Binary Tree Successfully Created

Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>4

Threaded Binary Tree :
Data: 3
Left: 99
Right: 4
Lbit: 0
Rbit: 1

Data: 4
Left: 3
Right: 5
Lbit: 0
Rbit: 0

Data: 5
Left: 3
Right: 7
Lbit: 1
Rbit: 1

Data: 6
Left: 5
Right: 7
Lbit: 0
Rbit: 0

Data: 7
Left: 6
Right: 10
Lbit: 1
Rbit: 0

Data: 10
Left: 5
Right: 11
Lbit: 1
Rbit: 1

Data: 11
Left: 10
Right: 99
Lbit: 0
Rbit: 0



Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>5

Threaded Binary Tree :
Data: 10
Left: 5
Right: 11
Lbit: 1
Rbit: 1

Data: 5
Left: 3
Right: 7
Lbit: 1
Rbit: 1

Data: 3
Left: 99
Right: 4
Lbit: 0
Rbit: 1

Data: 4
Left: 3
Right: 5
Lbit: 0
Rbit: 0

Data: 7
Left: 6
Right: 10
Lbit: 1
Rbit: 0

Data: 6
Left: 5
Right: 7
Lbit: 0
Rbit: 0

Data: 11
Left: 10
Right: 99
Lbit: 0
Rbit: 0



Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>6

Enter Value to be Searched: 5
Value found:
Data: 5
Left: 3
Right: 7
Lbit: 1
Rbit: 1


Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>6

Enter Value to be Searched: 11
Value found:
Data: 11
Left: 10
Right: 99
Lbit: 0
Rbit: 0


Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>6

Enter Value to be Searched: 12
Value not found!!!

Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>3

Enter Value to be Deleted: 5
Deletion has been successfully completed.

Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>4

Threaded Binary Tree :
Data: 3
Left: 99
Right: 4
Lbit: 0
Rbit: 1

Data: 4
Left: 3
Right: 6
Lbit: 0
Rbit: 0

Data: 6
Left: 3
Right: 7
Lbit: 1
Rbit: 1

Data: 7
Left: 6
Right: 10
Lbit: 0
Rbit: 0

Data: 10
Left: 6
Right: 11
Lbit: 1
Rbit: 1

Data: 11
Left: 10
Right: 99
Lbit: 0
Rbit: 0



Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>5

Threaded Binary Tree :
Data: 10
Left: 6
Right: 11
Lbit: 1
Rbit: 1

Data: 6
Left: 3
Right: 7
Lbit: 1
Rbit: 1

Data: 3
Left: 99
Right: 4
Lbit: 0
Rbit: 1

Data: 4
Left: 3
Right: 6
Lbit: 0
Rbit: 0

Data: 7
Left: 6
Right: 10
Lbit: 0
Rbit: 0

Data: 11
Left: 10
Right: 99
Lbit: 0
Rbit: 0



Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>3

Enter Value to be Deleted: 5
Data Not Found to delete

Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>2

Enter Value: 5
5 has been inserted in Threaded binary Tree

Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>4

Threaded Binary Tree :
Data: 3
Left: 99
Right: 4
Lbit: 0
Rbit: 1

Data: 4
Left: 3
Right: 5
Lbit: 0
Rbit: 1

Data: 5
Left: 4
Right: 6
Lbit: 0
Rbit: 0

Data: 6
Left: 3
Right: 7
Lbit: 1
Rbit: 1

Data: 7
Left: 6
Right: 10
Lbit: 0
Rbit: 0

Data: 10
Left: 6
Right: 11
Lbit: 1
Rbit: 1

Data: 11
Left: 10
Right: 99
Lbit: 0
Rbit: 0



Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>5

Threaded Binary Tree :
Data: 10
Left: 6
Right: 11
Lbit: 1
Rbit: 1

Data: 6
Left: 3
Right: 7
Lbit: 1
Rbit: 1

Data: 3
Left: 99
Right: 4
Lbit: 0
Rbit: 1

Data: 4
Left: 3
Right: 5
Lbit: 0
Rbit: 1

Data: 5
Left: 4
Right: 6
Lbit: 0
Rbit: 0

Data: 7
Left: 6
Right: 10
Lbit: 0
Rbit: 0

Data: 11
Left: 10
Right: 99
Lbit: 0
Rbit: 0



Enter the option:
1.Create Binary Search Tree
2.Insert Node
3.Delete Node
4.Inorder Traversal
5.Preorder Traversal
6.Search Key
7.Exit
>>>7

Thank You!
 *
 *
 */

