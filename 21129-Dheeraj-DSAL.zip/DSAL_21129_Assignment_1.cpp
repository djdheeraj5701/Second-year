//============================================================================
// Name        : DSAL_21129_Assignment_1.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Node{
public:
	int data;
	Node *child[2],*prev=NULL;
	Node(int data){
		this->data=data;
		child[0]=NULL;child[1]=NULL;
	}
};

class Stack{
public:
	Node *head;Stack(){head=NULL;}
	void push(Node *p){
		p->prev=head;
		head=p;
	}
	Node* pop(){
		Node *temp=head;
		head=head->prev;
		return temp;
	}
	Node* top(){
		Node *temp=head;
		return temp;
	}
};


class BinaryTree{
public:
	Node *root;
	BinaryTree(){root=NULL;}
	void add_node(){
		int temp;cout<<"Enter data: ";cin>>temp;
		Node *curr=new Node(temp);
		if(root==NULL){
			root=curr;
			cout<<temp<<" set as root"<<endl;
			return;
		}else{
			Node *p=root;
			cout<<"Enter 0/1 to add to left/right of current node"<<endl;
			while(true){
				cout<<"Current node: "<<p->data<<endl;
				cin>>temp;
				if(p->child[temp]){
					p=p->child[temp];
				}else{
					p->child[temp]=curr;
					cout<<curr->data<<" set as child"<<endl;
					return;
				}
			}
		}
	}
	void perform_order(int order,Node *q){
		switch(order){
		case 3:
			if(q){
				perform_order(order,q->child[0]);
				perform_order(order,q->child[1]);
				cout<<q->data<<",";
				return;
			}else{
				return;
			}
			break;
		case 2:
			if(q){
				perform_order(order,q->child[0]);
				cout<<q->data<<",";
				perform_order(order,q->child[1]);
				return;
			}else{
				return;
			}
			break;
		case 1:
			if(q){
				cout<<q->data<<",";
				perform_order(order,q->child[0]);
				perform_order(order,q->child[1]);
			}else{
				return;
			}
			break;
		}
	}
	void perform_order_nr(int order){
		if(root==NULL){
			return;
		}
		Stack stack=Stack();Node *p;
		switch(order){
		case 1:
			stack.push(root);
			while(stack.top()){
				p=stack.pop();
				cout<<p->data<<',';
				if(p->child[1]){
					stack.push(p->child[1]);
				}
				if(p->child[0]){
					stack.push(p->child[0]);
				}
			}
			return;
		case 2:
			p=root;
			while(true){
				while(p){
					stack.push(p);p=p->child[0];
				}
				if(stack.top()){
					p=stack.pop();
					cout<<p->data<<',';
					p=p->child[1];
				}else{
					return;
				}
			}
			break;
		case 3:
			p=root;Node *q=NULL;
			while(true){
				while(p){
					if(p->child[1]){
						stack.push(p->child[1]);
					}
					stack.push(p);
					p=p->child[0];
				}
				p=stack.pop();
				if(p->child[1]){
					if(stack.top()==p->child[1]){
						q=stack.pop();
						stack.push(p);
						p=q;
					}else{
						cout<<p->data<<',';p=NULL;
					}
				}else{
					cout<<p->data<<',';p=NULL;
				}
				if(stack.top()==NULL){
					return;
				}
			}
			break;
		}
	}
	void mirror_tree(Node *q){
		if(q){
			Node *p=q->child[0];
			q->child[0]=q->child[1];
			q->child[1]=p;
			mirror_tree(q->child[0]);
			mirror_tree(q->child[1]);
		}
	}
	int tree_height(Node *q,int height){
		if(root==NULL){
			return 0;
		}
		if(q){
			return max(
					tree_height(q->child[0],height+1),
					tree_height(q->child[1],height+1));
		}else{
			return height;
		}
	}
	Node* copy_tree(Node *q,Node *r){
		if(q){
			r=new Node(q->data);
			r->child[0]=copy_tree(q->child[0],r->child[0]);
			r->child[1]=copy_tree(q->child[1],r->child[1]);
			return r;
		}
		return NULL;

	}
	BinaryTree& operator =(BinaryTree *bt){
		BinaryTree nbt;
		Node *p=bt->root,*curr=NULL;
		nbt.root=copy_tree(p,curr);
		cout<<nbt.root->data;
		cout<<"Copying...."<<endl;
		nbt.perform_order(2, nbt.root);
		return nbt;
	}
	void count_nodes(Node *q,int count[]){
		if(q==NULL){
			return;
		}
		if(q->child[0] || q->child[1]){
			count[0]++;
			cout<<"intermediate: "<<q->data<<endl;
			if(q->child[0]){
				count_nodes(q->child[0],count);
			}
			if(q->child[1]){
				count_nodes(q->child[1],count);
			}
			return;
		}else{
			cout<<"leaf: "<<q->data<<endl;
			count[1]++;
			return;
		}
	}
	void erase_all_nodes(Node *q){
		if(q){
			erase_all_nodes(q->child[0]);
			erase_all_nodes(q->child[1]);
			cout<<"Erasing :"<<q->data<<endl;
			delete q;
			return;
		}
	}

};


int main() {
	BinaryTree *btt=new BinaryTree(),tmpcpy;int count[2];
	int c;
	while(true){
		cout<<"What to perform?"<<endl;
		cout<<"1. Insert a node"<<endl;
		cout<<"2. Perform traversal"<<endl;
		cout<<"3. Get Height of tree"<<endl;
		cout<<"4. Make a copy"<<endl;
		cout<<"5. Get all intermediate and leaf nodes"<<endl;
		cout<<"6. Swap the child"<<endl;
		cout<<"7. Erase all nodes"<<endl;
		cout<<"8. Exit"<<endl;
		cin>>c;
		if(c==8){
			cout<<"Thank you"<<endl;break;
		}
		switch(c){
		case 1:btt->add_node();break;
		case 2:
			cout<<"Choose from the following"<<endl;
			cout<<"1. Preorder\t2. Inorder\t3. Postorder"<<endl;
			cin>>c;
			btt->perform_order(c, btt->root);cout<<endl;
			btt->perform_order_nr(c);cout<<endl;
			break;
		case 3:cout<<"Height: "<<btt->tree_height(btt->root, 0)<<endl;break;
		case 4:
			tmpcpy=btt;
			cout<<"\nCopied"<<endl;
			break;
		case 5:
			count[0]=0;count[1]=0;
			btt->count_nodes(btt->root,count);
			cout<<"Total intermediate: "<<count[0]<<"\nTotal leaf: "<<count[1]<<endl;break;
		case 6:btt->mirror_tree(btt->root);break;
		case 7:btt->erase_all_nodes(btt->root);btt->root=NULL;break;
		}
	}
	return 0;
}

/*

What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
1
Enter data: 8
8 set as root
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
1
Enter data: 5
Enter 0/1 to add to left/right of current node
Current node: 8
0
5 set as child
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
1
Enter data: 4
Enter 0/1 to add to left/right of current node
Current node: 8
1
4 set as child
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
1
Enter data: 9
Enter 0/1 to add to left/right of current node
Current node: 8
0
Current node: 5
0
9 set as child
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
1
Enter data: 7
Enter 0/1 to add to left/right of current node
Current node: 8
0
Current node: 5
1
7 set as child
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
1
Enter data: 1
Enter 0/1 to add to left/right of current node
Current node: 8
0
Current node: 5
1
Current node: 7
0
1 set as child
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
1
Enter data: 12
Enter 0/1 to add to left/right of current node
Current node: 8
0
Current node: 5
1
Current node: 7
1
12 set as child
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
1
Enter data: 2
Enter 0/1 to add to left/right of current node
Current node: 8
0
Current node: 5
1
Current node: 7
1
Current node: 12
0
2 set as child
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
1
Enter data: 11
Enter 0/1 to add to left/right of current node
Current node: 8
1
Current node: 4
1
11 set as child
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
1
Enter data: 3
Enter 0/1 to add to left/right of current node
Current node: 8
1
Current node: 4
1
Current node: 11
0
3 set as child
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
2
Choose from the following
1. Preorder	2. Inorder	3. Postorder
1
8,5,9,7,1,12,2,4,11,3,
8,5,9,7,1,12,2,4,11,3,
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
2
Choose from the following
1. Preorder	2. Inorder	3. Postorder
2
9,5,1,7,2,12,8,4,3,11,
9,5,1,7,2,12,8,4,3,11,
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
2
Choose from the following
1. Preorder	2. Inorder	3. Postorder
3
9,1,2,12,7,5,3,11,4,8,
9,1,2,12,7,5,3,11,4,8,
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
3
Height: 5
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
4
8Copying....
9,5,1,7,2,12,8,4,3,11,
Copied
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
5
intermediate: 8
intermediate: 5
leaf: 9
intermediate: 7
leaf: 1
intermediate: 12
leaf: 2
intermediate: 4
intermediate: 11
leaf: 3
Total intermediate: 6
Total leaf: 4
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
7
Erasing :9
Erasing :1
Erasing :2
Erasing :12
Erasing :7
Erasing :5
Erasing :3
Erasing :11
Erasing :4
Erasing :8
What to perform?
1. Insert a node
2. Perform traversal
3. Get Height of tree
4. Make a copy
5. Get all intermediate and leaf nodes
6. Swap the child
7. Erase all nodes
8. Exit
8
Thank you

 */
